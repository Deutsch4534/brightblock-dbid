module.exports = {
  main: 'demo'
}